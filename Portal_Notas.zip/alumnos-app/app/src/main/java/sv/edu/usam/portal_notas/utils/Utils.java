package sv.edu.usam.portal_notas.utils;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Utils {
    public static final String URL_PORTAL_ALUMNO_WS="http://192.168.1.3:8080/alumnos-ws/";
    public static final ObjectMapper mapper= new ObjectMapper();
}
